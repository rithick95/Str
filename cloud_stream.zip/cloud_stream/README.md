# CloudStream
1. Colab: run server/telegram_stream_server.py as ONE cell, copy the "Server link".
2. App: paste Server link + Telegram channel link -> Load -> tap a card.
Build: GitHub Actions -> artifacts android-apk / windows-app.
