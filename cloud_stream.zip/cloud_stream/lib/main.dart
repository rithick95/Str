import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';

String resolveUrl(String u) {
  // Google Drive share link -> direct download link
  final d = RegExp(r'drive\.google\.com/(?:file/d/|open\?id=|uc\?.*?id=)([\w-]+)').firstMatch(u);
  if (d != null) {
    return 'https://drive.google.com/uc?export=download&confirm=t&id=${d.group(1)}';
  }
  // Dropbox share link -> raw stream
  if (u.contains('dropbox.com')) {
    return u.replaceAll('dl=0', 'raw=1').replaceAll('www.dropbox.com', 'dl.dropboxusercontent.com');
  }
  return u;
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  MediaKit.ensureInitialized();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'CloudStream',
        theme: ThemeData.dark().copyWith(
          scaffoldBackgroundColor: const Color(0xFF0C111B),
          colorScheme: const ColorScheme.dark(primary: Color(0xFF1F80E0)),
        ),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  final pages = const [
    HomePage(),
    Center(child: Text('Downloads')),
    Center(child: Text('Settings'))
  ];
  static const dests = [
    NavigationDestination(icon: Icon(Icons.home), label: 'Home'),
    NavigationDestination(icon: Icon(Icons.download), label: 'Downloads'),
    NavigationDestination(icon: Icon(Icons.settings), label: 'Settings'),
  ];

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width > 700;
    return Scaffold(
      body: Row(children: [
        if (wide)
          NavigationRail(
            selectedIndex: i,
            onDestinationSelected: (v) => setState(() => i = v),
            labelType: NavigationRailLabelType.all,
            destinations: dests
                .map((d) => NavigationRailDestination(
                    icon: d.icon, label: Text(d.label)))
                .toList(),
          ),
        Expanded(child: pages[i]),
      ]),
      bottomNavigationBar: wide
          ? null
          : NavigationBar(
              selectedIndex: i,
              onDestinationSelected: (v) => setState(() => i = v),
              destinations: dests),
    );
  }
}

class Item {
  final int id, size, duration;
  final String name, channel;
  Item(this.id, this.name, this.size, this.duration, this.channel);
  factory Item.fromJson(Map<String, dynamic> j) => Item(
      (j['id'] as num).toInt(),
      j['name'].toString(),
      (j['size'] as num? ?? 0).toInt(),
      (j['duration'] as num? ?? 0).toInt(),
      j['channel'].toString());
}

String fmtSize(int b) {
  if (b >= 1073741824) return '${(b / 1073741824).toStringAsFixed(1)} GB';
  return '${(b / 1048576).toStringAsFixed(0)} MB';
}

String fmtDur(int s) {
  if (s <= 0) return '';
  final h = s ~/ 3600, m = (s % 3600) ~/ 60;
  return h > 0 ? '${h}h ${m}m' : '${m}m';
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final server = TextEditingController();
  final link = TextEditingController();
  List<Item> items = [];
  bool loading = false;
  String? msg;
  String base = '';
  String token = '';

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      server.text = p.getString('server') ?? '';
      if (mounted) setState(() {});
    });
  }

  Future<void> load() async {
    final l = link.text.trim();
    if (l.isEmpty) return;
    if (!(l.contains('t.me') || l.startsWith('@'))) {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => PlayerPage(url: l)));
      return;
    }
    setState(() {
      loading = true;
      msg = null;
      items = [];
    });
    try {
      final u = Uri.tryParse(server.text.trim());
      if (u == null || !u.hasAuthority) {
        throw 'Paste the Server link from Colab first';
      }
      base = '${u.scheme}://${u.authority}';
      token = u.queryParameters['token'] ?? '';
      final p = await SharedPreferences.getInstance();
      await p.setString('server', server.text.trim());
      final r = await Dio().get('$base/list',
          queryParameters: {'channel': l, 'token': token, 'limit': 300},
          options: Options(receiveTimeout: const Duration(seconds: 90)));
      final data = r.data is String ? jsonDecode(r.data) : r.data;
      items = (data['items'] as List)
          .map((e) => Item.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      if (items.isEmpty) msg = 'No videos found in that channel';
    } on DioException catch (e) {
      msg = 'Server error: ${e.response?.data ?? e.message}';
    } catch (e) {
      msg = '$e';
    }
    if (mounted) setState(() => loading = false);
  }

  void play(Item it) {
    final url = '$base/stream/${it.channel}/${it.id}?token=$token';
    Navigator.push(
        context, MaterialPageRoute(builder: (_) => PlayerPage(url: url)));
  }

  @override
  Widget build(BuildContext context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('CloudStream',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(
              controller: server,
              decoration: const InputDecoration(
                  labelText: 'Server link (from Colab, needed for Telegram)',
                  border: OutlineInputBorder()),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: link,
              decoration: const InputDecoration(
                  labelText: 'Channel link (t.me/...) or direct video link',
                  border: OutlineInputBorder()),
            ),
            const SizedBox(height: 10),
            Row(children: [
              ElevatedButton(
                  onPressed: loading ? null : load, child: const Text('Load')),
              const SizedBox(width: 12),
              OutlinedButton(
                onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const PlayerPage(
                            url:
                                'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'))),
                child: const Text('Sample'),
              ),
            ]),
            const SizedBox(height: 12),
            if (loading) const LinearProgressIndicator(),
            if (msg != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: SelectableText(msg!,
                    style: const TextStyle(color: Colors.redAccent)),
              ),
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 220,
                    childAspectRatio: 0.8,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10),
                itemCount: items.length,
                itemBuilder: (_, i) {
                  final it = items[i];
                  return InkWell(
                    onTap: () => play(it),
                    child: Card(
                      clipBehavior: Clip.antiAlias,
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Container(
                                width: double.infinity,
                                decoration: const BoxDecoration(
                                    gradient: LinearGradient(
                                        colors: [
                                      Color(0xFF1F3A5F),
                                      Color(0xFF0C111B)
                                    ],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight)),
                                child: const Icon(Icons.play_circle_fill,
                                    size: 48, color: Colors.white70),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(it.name,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w600)),
                                    const SizedBox(height: 2),
                                    Text(
                                        '${fmtSize(it.size)}  ${fmtDur(it.duration)}',
                                        style: const TextStyle(
                                            fontSize: 12,
                                            color: Colors.white54)),
                                  ]),
                            ),
                          ]),
                    ),
                  );
                },
              ),
            ),
          ]),
        ),
      );
}

class PlayerPage extends StatefulWidget {
  final String url;
  const PlayerPage({super.key, required this.url});
  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  late final player = Player(
      configuration: const PlayerConfiguration(bufferSize: 64 * 1024 * 1024));
  late final controller = VideoController(player);
  String? error;
  bool buffering = true;
  late final String finalUrl = resolveUrl(widget.url);

  @override
  void initState() {
    super.initState();
    player.stream.error.listen((e) {
      if (mounted) setState(() => error = e);
    });
    player.stream.buffering.listen((b) {
      if (mounted) setState(() => buffering = b);
    });
    player.open(Media(finalUrl));
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Playing')),
        body: Column(children: [
          AspectRatio(
            aspectRatio: 16 / 9,
            child: Stack(alignment: Alignment.center, children: [
              Video(controller: controller),
              if (buffering && error == null)
                const CircularProgressIndicator(),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: SelectableText(
              error != null
                  ? 'Cannot play: $error\n\nLink used:\n$finalUrl'
                  : 'Link used:\n$finalUrl',
              style: TextStyle(
                  color: error != null ? Colors.redAccent : Colors.white54),
            ),
          ),
        ]),
      );
}
