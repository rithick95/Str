!pip -q install telethon cryptg aiohttp
import os, re, asyncio, secrets, subprocess, threading
from aiohttp import web
from telethon import TelegramClient

# ---- stop old copies if you re-run this cell ----
try: await runner.cleanup()
except NameError: pass
try: proc.kill()
except NameError: pass
try: await client.disconnect()
except NameError: pass

api_id = 0                       # your NEW api_id (numbers)
api_hash = 'YOUR_API_HASH'       # your NEW api_hash
PORT = 8080
CHUNK = 512 * 1024
TOKEN = secrets.token_urlsafe(8)

client = TelegramClient('/content/tg_stream', api_id, api_hash)   # separate session
await client.start()             # asks phone + code the first time
await client.get_dialogs()

def parse_channel(s):
    s = s.strip()
    m = re.search(r't\.me/c/(\d+)', s)
    if m: return '-100' + m.group(1)
    m = re.search(r't\.me/(?:s/)?([A-Za-z0-9_]+)', s)
    if m: return m.group(1)
    return s.lstrip('@')

def to_peer(x):
    return int(x) if x.lstrip('-').isdigit() else x

def is_video(m):
    return bool(m.file) and (bool(m.video) or (m.file.mime_type or '').startswith('video/'))

async def h_list(request):
    if request.query.get('token') != TOKEN:
        return web.json_response({'error': 'bad token'}, status=403)
    key = parse_channel(request.query.get('channel', ''))
    limit = min(int(request.query.get('limit', 100)), 500)
    try:
        ent = await client.get_entity(to_peer(key))
    except Exception as e:
        return web.json_response({'error': f'cannot open channel: {e}'}, status=400)
    items = []
    async for m in client.iter_messages(ent, limit=2000):
        if not is_video(m): continue
        name = (m.file.name or '').strip()
        if not name: name = (m.message or '').strip().split('\n')[0][:120]
        if not name: name = f'Video {m.id}'
        items.append({'id': m.id, 'name': name, 'size': m.file.size or 0,
                      'duration': m.file.duration or 0, 'channel': key})
        if len(items) >= limit: break
    return web.json_response({'items': items})

async def h_stream(request):
    if request.query.get('token') != TOKEN:
        return web.Response(status=403)
    key = request.match_info['channel']
    msg = await client.get_messages(to_peer(key), ids=int(request.match_info['mid']))
    if not msg or not msg.file:
        return web.Response(status=404)
    size = msg.file.size
    start, end = 0, size - 1
    rng = request.headers.get('Range')
    if rng:
        m = re.match(r'bytes=(\d*)-(\d*)', rng)
        if m and m.group(1):
            start = int(m.group(1))
            if m.group(2): end = min(int(m.group(2)), size - 1)
        elif m and m.group(2):
            start = max(size - int(m.group(2)), 0)
    if start >= size:
        return web.Response(status=416, headers={'Content-Range': f'bytes */{size}'})
    length = end - start + 1
    headers = {'Content-Type': msg.file.mime_type or 'video/mp4',
               'Accept-Ranges': 'bytes', 'Content-Length': str(length)}
    if rng: headers['Content-Range'] = f'bytes {start}-{end}/{size}'
    if request.method == 'HEAD':
        return web.Response(status=206 if rng else 200, headers=headers)
    resp = web.StreamResponse(status=206 if rng else 200, headers=headers)
    await resp.prepare(request)
    aligned = start - (start % CHUNK)
    sent, first = 0, True
    try:
        async for chunk in client.iter_download(msg.media, offset=aligned, request_size=CHUNK):
            if first:
                chunk = chunk[start - aligned:]
                first = False
            if sent + len(chunk) > length:
                chunk = chunk[:length - sent]
            await resp.write(chunk)
            sent += len(chunk)
            if sent >= length: break
    except ConnectionResetError:
        pass
    return resp

app = web.Application()
app.add_routes([web.get('/list', h_list), web.route('*', '/stream/{channel}/{mid}', h_stream)])
runner = web.AppRunner(app)
await runner.setup()
await web.TCPSite(runner, '0.0.0.0', PORT).start()

# ---- public link via Cloudflare tunnel ----
if not os.path.exists('/content/cloudflared'):
    os.system('wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -O /content/cloudflared && chmod +x /content/cloudflared')
proc = subprocess.Popen(['/content/cloudflared', 'tunnel', '--url', f'http://localhost:{PORT}'],
                        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
url = None
for line in proc.stderr:
    m = re.search(r'https://[a-z0-9-]+\.trycloudflare\.com', line)
    if m: url = m.group(0); break
threading.Thread(target=lambda: [None for _ in proc.stderr], daemon=True).start()

print('\n==== PASTE THIS IN THE APP (Server link) ====')
print(f'{url}/?token={TOKEN}')
print('=============================================')
await client.run_until_disconnected()
